# Jarvis para Android

Asistente personal con voz que usa Claude como cerebro y puede:

- Abrir aplicaciones
- Reproducir música en Spotify y buscar en YouTube
- Leer tus notificaciones y mensajes recibidos (WhatsApp, Telegram, SMS...)
- Dejar mensajes de WhatsApp o SMS escritos y listos para enviar

## Cómo generar el APK

1. Instalá **Android Studio** (https://developer.android.com/studio).
2. `File > Open` y elegí la carpeta `jarvis`. Esperá a que termine la sincronización de Gradle.
3. Menú `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Cuando termine, tocá **locate** en el aviso. El archivo queda en
   `app/build/outputs/apk/debug/app-debug.apk`.
5. Pasalo al celular e instalalo (hay que permitir "instalar apps de orígenes desconocidos").

## Primer uso

1. Creá una API key en https://console.anthropic.com y pegala en la app.
2. Tocá **Activar lectura de notificaciones** y habilitá Jarvis.
   - En Android 13+, si aparece bloqueado: `Ajustes > Apps > Jarvis > ⋮ > Permitir ajustes restringidos`
     y volvé a intentar.
3. Escribí o tocá 🎤 y hablá. Ejemplos:
   - "Abrí Spotify"
   - "Poné algo de Soda Stereo en Spotify"
   - "Buscá en YouTube tutoriales de guitarra"
   - "Leeme los últimos mensajes"
   - "Prepará un WhatsApp para 595981123456 diciendo que llego en 10 minutos"

## Límites a tener en cuenta

- **Spotify:** la reproducción automática depende de la versión de la app y de tener Premium.
  A veces solo abre la búsqueda.
- **YouTube:** abre los resultados de búsqueda; no inicia el video solo.
- **Mensajes:** Jarvis los deja escritos pero **vos tocás Enviar**. Responder solo, sin tocar,
  requiere el servicio de Accesibilidad de Android y es mucho más delicado.
- **Leer mensajes:** solo ve lo que aparece como notificación, no el historial de los chats.
- **API key:** queda guardada en el celular. Usala solo para vos y no compartas el APK con la key puesta.

## Estructura

- `MainActivity.kt`: pantalla, voz (reconocimiento y síntesis)
- `ClaudeClient.kt`: conexión con la API de Claude y bucle de herramientas
- `Tools.kt`: las acciones que Jarvis puede hacer
- `JarvisNotificationService.kt`: captura de notificaciones
