package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyInput: EditText
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private lateinit var tools: Tools
    private var recognizer: SpeechRecognizer? = null
    private var client: ClaudeClient? = null
    private var clientKey = ""

    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) listen() else append("Sistema", "Sin permiso de micrófono.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        log = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        keyInput = findViewById(R.id.keyInput)
        input = findViewById(R.id.input)
        tools = Tools(applicationContext)

        keyInput.setText(prefs.getString("key", ""))

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts.language = Locale("es")
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener { submitInput() }
        findViewById<Button>(R.id.micButton).setOnClickListener { startListening() }
        findViewById<Button>(R.id.notifButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput()
                true
            } else false
        }

        append("Jarvis", "Hola, soy Jarvis. Pegá tu API key arriba y pedime lo que quieras.")
    }

    private fun submitInput() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        send(text)
    }

    private fun startListening() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) listen() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            append("Sistema", "Este celular no tiene reconocimiento de voz disponible.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!text.isNullOrBlank()) send(text)
                }

                override fun onError(error: Int) {
                    append("Sistema", "No te escuché bien (código $error). Probá de nuevo.")
                }

                override fun onReadyForSpeech(params: Bundle?) {
                    append("Sistema", "Escuchando…")
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-419")
        }
        recognizer?.startListening(intent)
    }

    private fun send(text: String) {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            append("Sistema", "Pegá tu API key arriba primero.")
            return
        }
        prefs.edit().putString("key", key).apply()
        if (client == null || key != clientKey) {
            client = ClaudeClient(key, tools)
            clientKey = key
        }

        append("Vos", text)
        val current = client!!
        lifecycleScope.launch {
            val answer = withContext(Dispatchers.IO) {
                try {
                    current.ask(text)
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
            }
            append("Jarvis", answer)
            tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun append(who: String, text: String) {
        runOnUiThread {
            log.append("$who: $text\n\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
