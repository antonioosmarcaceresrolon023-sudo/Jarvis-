package com.jarvis.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Guarda las últimas notificaciones (WhatsApp, Telegram, SMS, etc.)
 * para que Jarvis pueda leerlas. Requiere que el usuario active
 * "Acceso a notificaciones" para esta app en los ajustes.
 */
class JarvisNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: return

        val appName = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        synchronized(recent) {
            recent.add(0, "[$appName] $title: $text")
            while (recent.size > 30) recent.removeAt(recent.size - 1)
        }
    }

    override fun onListenerConnected() {
        connected = true
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    companion object {
        val recent = mutableListOf<String>()

        @Volatile
        var connected = false
    }
}
