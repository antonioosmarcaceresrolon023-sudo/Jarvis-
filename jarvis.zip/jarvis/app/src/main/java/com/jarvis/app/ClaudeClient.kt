package com.jarvis.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Cliente mínimo de la API de Claude con bucle de uso de herramientas. */
class ClaudeClient(private val apiKey: String, private val tools: Tools) {

    private val http = OkHttpClient.Builder()
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val history = JSONArray()

    private val system =
        "Sos Jarvis, un asistente personal que vive en el celular del usuario. " +
        "Respondé siempre en español, de forma breve y directa (se leen en voz alta). " +
        "Usá las herramientas para ejecutar acciones: abrir apps, reproducir música en " +
        "Spotify o YouTube, leer notificaciones y preparar mensajes. " +
        "Si falta un dato (por ejemplo el número de teléfono), preguntalo en vez de inventarlo. " +
        "Nunca digas que enviaste un mensaje: solo lo dejás preparado y el usuario toca enviar."

    fun ask(userText: String): String {
        val start = history.length()
        try {
            history.put(JSONObject().put("role", "user").put("content", userText))

            repeat(6) {
                val resp = call()
                val content = resp.getJSONArray("content")
                history.put(JSONObject().put("role", "assistant").put("content", content))

                if (resp.optString("stop_reason") != "tool_use") {
                    return extractText(content)
                }

                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val block = content.getJSONObject(i)
                    if (block.getString("type") == "tool_use") {
                        val output = tools.run(block.getString("name"), block.getJSONObject("input"))
                        results.put(
                            JSONObject()
                                .put("type", "tool_result")
                                .put("tool_use_id", block.getString("id"))
                                .put("content", output)
                        )
                    }
                }
                history.put(JSONObject().put("role", "user").put("content", results))
            }
            return "Hice varios pasos pero no pude terminar. Probá de nuevo."
        } catch (e: Exception) {
            // Evita dejar el historial a medias (tool_use sin tool_result)
            while (history.length() > start) history.remove(history.length() - 1)
            throw e
        }
    }

    private fun call(): JSONObject {
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 1024)
            .put("system", system)
            .put("tools", tools.schema())
            .put("messages", history)

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw RuntimeException("API ${response.code}: $text")
            return JSONObject(text)
        }
    }

    private fun extractText(content: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.getString("type") == "text") sb.append(block.getString("text"))
        }
        return sb.toString().ifBlank { "Listo." }
    }
}
