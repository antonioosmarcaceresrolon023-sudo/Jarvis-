package com.jarvis.app

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

/** Herramientas que Claude puede ejecutar en el celular. */
class Tools(private val ctx: Context) {

    // ---- Definición de herramientas (lo que Claude ve) ----

    fun schema(): JSONArray = JSONArray()
        .put(
            tool(
                "open_app",
                "Abre una aplicación instalada en el celular por su nombre (ej: WhatsApp, Spotify, Cámara).",
                mapOf("app_name" to "Nombre de la app"),
                listOf("app_name")
            )
        )
        .put(
            tool(
                "play_youtube",
                "Busca y abre en YouTube una canción, video o artista.",
                mapOf("query" to "Qué buscar en YouTube"),
                listOf("query")
            )
        )
        .put(
            tool(
                "play_spotify",
                "Busca y reproduce música en Spotify (canción, artista o álbum).",
                mapOf("query" to "Qué reproducir en Spotify"),
                listOf("query")
            )
        )
        .put(
            tool(
                "send_whatsapp",
                "Abre WhatsApp con un mensaje ya escrito para un número. El usuario debe tocar enviar.",
                mapOf(
                    "phone" to "Número con código de país, sin + ni espacios (ej: 595981123456)",
                    "message" to "Texto del mensaje"
                ),
                listOf("phone", "message")
            )
        )
        .put(
            tool(
                "send_sms",
                "Abre la app de SMS con un mensaje ya escrito. El usuario debe tocar enviar.",
                mapOf("phone" to "Número de teléfono", "message" to "Texto del mensaje"),
                listOf("phone", "message")
            )
        )
        .put(
            tool(
                "read_notifications",
                "Lee las últimas notificaciones y mensajes recibidos en el celular (WhatsApp, Telegram, SMS, etc.).",
                emptyMap(),
                emptyList()
            )
        )

    private fun tool(
        name: String,
        description: String,
        props: Map<String, String>,
        required: List<String>
    ): JSONObject {
        val properties = JSONObject()
        props.forEach { (k, v) ->
            properties.put(k, JSONObject().put("type", "string").put("description", v))
        }
        return JSONObject()
            .put("name", name)
            .put("description", description)
            .put(
                "input_schema",
                JSONObject()
                    .put("type", "object")
                    .put("properties", properties)
                    .put("required", JSONArray(required))
            )
    }

    // ---- Ejecución ----

    fun run(name: String, input: JSONObject): String = try {
        when (name) {
            "open_app" -> openApp(input.getString("app_name"))
            "play_youtube" -> playYoutube(input.getString("query"))
            "play_spotify" -> playSpotify(input.getString("query"))
            "send_whatsapp" -> sendWhatsapp(input.getString("phone"), input.getString("message"))
            "send_sms" -> sendSms(input.getString("phone"), input.getString("message"))
            "read_notifications" -> readNotifications()
            else -> "Herramienta desconocida: $name"
        }
    } catch (e: Exception) {
        "Error ejecutando $name: ${e.message}"
    }

    private fun start(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "No encontré ninguna app llamada '$name'."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "No pude abrir '$name'."
        start(intent)
        return "Abrí ${match.loadLabel(pm)}."
    }

    private fun playYoutube(query: String): String {
        return try {
            start(
                Intent(Intent.ACTION_SEARCH)
                    .setPackage("com.google.android.youtube")
                    .putExtra("query", query)
            )
            "Abrí YouTube con la búsqueda '$query'."
        } catch (e: ActivityNotFoundException) {
            start(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                )
            )
            "YouTube no está instalado; abrí la búsqueda '$query' en el navegador."
        }
    }

    private fun playSpotify(query: String): String {
        return try {
            start(
                Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .setPackage("com.spotify.music")
                    .putExtra(SearchManager.QUERY, query)
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            )
            "Pedí a Spotify reproducir '$query'."
        } catch (e: ActivityNotFoundException) {
            try {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")))
                "Abrí la búsqueda '$query' en Spotify."
            } catch (e2: ActivityNotFoundException) {
                "Spotify no está instalado en este celular."
            }
        }
    }

    private fun sendWhatsapp(phone: String, message: String): String {
        val digits = phone.filter { it.isDigit() }
        start(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
            )
        )
        return "Abrí WhatsApp con el mensaje listo. El usuario tiene que tocar enviar."
    }

    private fun sendSms(phone: String, message: String): String {
        start(
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}"))
                .putExtra("sms_body", message)
        )
        return "Abrí SMS con el mensaje listo. El usuario tiene que tocar enviar."
    }

    private fun readNotifications(): String {
        if (!JarvisNotificationService.connected) {
            return "El acceso a notificaciones no está activado. Pedile al usuario que toque " +
                "'Activar lectura de notificaciones' y habilite Jarvis."
        }
        val items = synchronized(JarvisNotificationService.recent) {
            JarvisNotificationService.recent.take(15)
        }
        return if (items.isEmpty()) "No hay notificaciones recientes." else items.joinToString("\n")
    }
}
